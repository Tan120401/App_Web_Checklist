import os
from time import sleep
from pywinauto import Application, Desktop
from selenium.webdriver.common.by import By

from common_lib import download_directory, connect_app, check_program_installed, \
    download_and_execute, print_all_windows, click_without_id, click_object, download_by_link, click_by_xpath, \
    get_latest_file, run_file_exe, download_exe_file, install_app_silent, check_app_installed, close_app, check_app_existed, get_link


def PuTTY_SSH(app_name, file_name_exe, download_link):
    app_name = "putty"
    try:
        # Check app is installed
        if check_app_existed(app_name):
            return True

        file_path = os.path.join(download_directory, file_name_exe)
        if os.path.isfile(file_path):
            return True
        if not os.path.isfile(file_path):
            # Download file
            driver = get_link(download_link)
            # Click nút đầu tiên bằng JavaScript
            element = driver.find_element(By.XPATH, '/html/body/div[2]/div[2]/span[2]/a')
            driver.execute_script("arguments[0].click();", element)
            sleep(30)
            # click download

            # Get latest file
            file_path = get_latest_file()
            if os.path.isfile(file_path):
                return True
            else:
                print('Download app error')
                return False

    except Exception as e:
        print(f'error app: {e}')
        return False
test = PuTTY_SSH('PuTTY SSH','putty.exe','https://www.chiark.greenend.org.uk/~sgtatham/putty/latest.html')
print(test)