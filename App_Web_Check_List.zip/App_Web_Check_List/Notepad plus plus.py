import os
from time import sleep
from pywinauto import Application, Desktop
from selenium.webdriver.common.by import By

from common_lib import download_directory, connect_app, check_program_installed, \
    download_and_execute, print_all_windows, click_without_id, click_object, download_by_link, click_by_xpath, \
    get_latest_file, run_file_exe, download_exe_file, install_app_silent, check_app_installed, close_app, check_app_existed, get_link


def Notepad_plus_plus(app_name, file_name_exe, download_link):
    app_name = "Notepad++"
    try:
        # Check app is installed
        if check_app_existed(app_name):
            return True

        file_path = os.path.join(download_directory, file_name_exe)
        if not os.path.isfile(file_path):
            # Download file
            driver = get_link(download_link)
            # Click nút đầu tiên bằng JavaScript
            element = driver.find_element(By.XPATH, '//*[@id="main"]/ul/li[1]/h2/a')
            driver.execute_script("arguments[0].click();", element)
            sleep(2)

            # Click nút thứ hai
            element = driver.find_element(By.XPATH, '//*[@id="main"]/ul[1]/li[1]/a[1]')
            driver.execute_script("arguments[0].click();", element)
            sleep(30)
            # click download

            # Get latest file
            file_path = get_latest_file()

        # # Download file
        # file_path = download_exe_file(file_name_exe, download_link, 30)

        # Run file exe
        if file_path:
            # Install app
            install_app_silent(file_path, "/S")
        else:
            print('Time out')
            return False

        # Check app installed
        for i in range(60):
            if check_app_existed(app_name):
                return True
            sleep(5)

    except Exception as e:
        print(f'error app: {e}')
        return False
test = Notepad_plus_plus('Notepad plus plus','npp.8.7.8.Installer.x64.exe','https://notepad-plus-plus.org/downloads/')
print(test)