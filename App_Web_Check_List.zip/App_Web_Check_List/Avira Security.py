import os
from time import sleep

from AppOpener import close
from pywinauto import Application, Desktop
from selenium.webdriver.common.by import By

from common_lib import download_directory, connect_app, check_program_installed, \
    download_and_execute, print_all_windows, click_without_id, click_object, download_by_link, click_by_xpath, \
    get_latest_file, run_file_exe, download_exe_file, install_app_silent, check_app_installed, close_app, check_app_existed


def Avira_Security(app_name, file_name_exe, download_link):
    app_name = "Avira"
    try:
        # Check app is installed
        if check_app_existed(app_name):
            return True

        file_path = os.path.join(download_directory, file_name_exe)
        if not os.path.isfile(file_path):
            file_path = download_exe_file(file_name_exe, download_link, 60)

        # Run file exe
        run_file_exe(file_path)
        sleep(5)

        # Connect app and install
        app = Application(backend='uia').connect(title='Avira Setup', timeout=30)
        target_window = app.window(title='Avira Setup')
        button = target_window.child_window(title='Agree and Install', control_type='Button')
        button.wait('exists ready', timeout=30).click_input()
        target_window.wait_not('enabled', timeout=300)
        sleep(5)
        close('Avira.Spotlight.UI.Application.exe')

        # Check app installed
        for i in range(60):
            if check_app_existed(app_name):
                return True
            sleep(5)

    except Exception as e:
        print(f'error app: {e}')
        return False
test = Avira_Security('Avira Security','avira_en_sptl1_71181794-1741834844-1741834844-1__phpws-spotlight-release.exe','https://www.avira.com/en/start-download/product/2262/-I12e2mvtstLKUkGnG-U3eKJ0uofLc0hU9xCRx-aYuBBOiLOFMgKktbw-KT6YPslY3X0hFL4yXlTfNsbPfqL_A')
print(test)


