import os
from time import sleep

from pywinauto import Application, Desktop
from selenium.webdriver.common.by import By

from common_lib import download_directory, connect_app, check_program_installed, \
    download_and_execute, print_all_windows, click_without_id, click_object, download_by_link, click_by_xpath, \
    get_latest_file, run_file_exe, download_exe_file, install_app_silent, check_app_installed, close_app, check_app_existed


def DBeaver(app_name, file_name_exe, download_link):
    try:
        # Check app is installed
        if check_app_existed(app_name):
            return True

        file_path = os.path.join(download_directory, file_name_exe)
        if not os.path.isfile(file_path):
            file_path = download_exe_file(file_name_exe, download_link, 60)

        # Run file exe
        run_file_exe(file_path)
        sleep(5)

        try:
            # Connect app
            target_window = connect_app('Installer Language')
            click_without_id(target_window, 'OK', 'Button')
            sleep(2)
        except Exception:
            pass

        app = Application(backend='win32').connect(title="DBeaver Community 25.0.0 (x86_64) Setup")
        target_window = app['DBeaver Community 25.0.0 (x86_64) Setup']

        button = target_window.child_window(title="&Next >", class_name="Button")
        button.set_focus()
        button.click_input()
        sleep(2)

        button = target_window.child_window(title="I &Agree", class_name="Button")
        button.click_input()
        sleep(2)

        button = target_window.child_window(title="&Next >", class_name="Button")
        button.click_input()
        sleep(2)

        button = target_window.child_window(title="&Next >", class_name="Button")
        button.click_input()
        sleep(2)

        button = target_window.child_window(title="&Next >", class_name="Button")
        button.click_input()
        sleep(2)

        button = target_window.child_window(title="&Install", class_name="Button")
        button.click_input()
        sleep(30)
        target_window.print_control_identifiers()

        finish_button = target_window.child_window(title="&Finish", class_name="Button")
        finish_button.wait('exists', timeout=60).click_input()

        # Check app installed
        for i in range(60):
            if check_app_existed(app_name):
                return True
            sleep(5)

    except Exception as e:
        print(f'error app: {e}')
        return False

test = DBeaver('DBeaver', 'dbeaver-ce-25.0.0-x86_64-setup.exe', 'https://dbeaver.io/download/files/dbeaver-ce-latest-x86_64-setup.exe')
print(test)
