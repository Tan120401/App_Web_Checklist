import os
from time import sleep
from pywinauto import Application, Desktop
from selenium.webdriver.common.by import By
from common_lib import download_directory, connect_app, check_program_installed, \
    download_and_execute, print_all_windows, click_without_id, click_object, download_by_link, click_by_xpath, \
    get_latest_file, run_file_exe, download_exe_file, install_app_silent, check_app_installed, close_app, check_app_existed, get_link


def Kaspersky(app_name, file_name_exe, download_link):
    try:
        # Check app is installed
        if check_app_existed(app_name):
            return True
        file_path = os.path.join(download_directory, file_name_exe)
        if not os.path.isfile(file_path):
            # Download file
            driver = get_link(download_link)
            # Click nút đầu tiên bằng JavaScript
            element = driver.find_element(By.XPATH, '//*[@id="__next"]/div/div/div/main/div/section/div/div[3]/div[2]/div/div[2]/div/div[3]/div[2]/button/span/span')
            driver.execute_script("arguments[0].click();", element)
            sleep(60)
            # click download

            # Get latest file
            file_path = get_latest_file()

        # Run file exe
        run_file_exe(file_path)
        sleep(5)

        app = Application(backend='uia').connect(title='Kaspersky Standard')
        target_window = app.window(title='Kaspersky Standard')

        target_window.print_control_identifiers()
        button = target_window.child_window(title='Continue', control_type='Button')
        button.wait('exists ready', timeout=10).click_input()

        # Check app installed
        for i in range(60):
            if check_app_existed(app_name):
                sleep(30)
                target_window.close()
                return True
            sleep(5)

    except Exception as e:
        print(f'error app: {e}')
        return False
test = Kaspersky('Kaspersky','kaspersky4win202121.20.8.505en_46557.exe','https://www.kaspersky.com/downloads/standard-free-trial-2')
print(test)


