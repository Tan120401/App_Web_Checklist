import os
from time import sleep

from pywinauto import Application, Desktop
from selenium.webdriver.common.by import By

from common_lib import download_directory, connect_app, check_program_installed, \
    download_and_execute, print_all_windows, click_without_id, click_object, download_by_link, click_by_xpath, \
    get_latest_file, run_file_exe, download_exe_file, install_app_silent, check_app_installed, close_app, check_app_existed


def Cygwin64_Terminal(app_name, file_name_exe, download_link):
    try:
        # Check app is installed
        if check_app_existed(app_name):
            return True

        file_path = os.path.join(download_directory, file_name_exe)
        if not os.path.isfile(file_path):
            file_path = download_exe_file(file_name_exe, download_link, 60)

        # Run file exe
        run_file_exe(file_path)
        sleep(5)

        #Connect app
        target_window = connect_app('Cygwin Setup')
        click_without_id(target_window, 'Next >', 'Button')
        sleep(2)
        click_without_id(target_window, 'Next >', 'Button')
        sleep(2)
        click_without_id(target_window, 'Next >', 'Button')
        sleep(2)
        click_without_id(target_window, 'Next >', 'Button')
        sleep(2)
        click_without_id(target_window, 'Next >', 'Button')
        sleep(2)
        object1 = target_window.child_window(title='https://cygwin.mirror.constant.com')
        object1.wait('exists', timeout=30).click_input()
        object2 = target_window.child_window(title='Next >', control_type = 'Button')
        object2.wait('exists', timeout=5).click_input()
        sleep(10)
        object3 = target_window.child_window(title='Next >', control_type='Button')
        object3.wait('exists', timeout=5).click_input()
        sleep(10)
        object4 = target_window.child_window(title='Next >', control_type='Button')
        object4.wait('exists', timeout=5).click_input()
        object5 = target_window.child_window(title='Finish', control_type='Button')
        object5.wait('exists', timeout=180).click_input()

        # Check app installed
        for i in range(60):
            if check_app_existed(app_name):
                return True
            sleep(5)

    except Exception as e:
        print(f'error app: {e}')
        return False
test = Cygwin64_Terminal('Cygwin64 Terminal','setup-x86_64.exe','https://cygwin.com/setup-x86_64.exe')
print(test)