import os

from pywinauto import Desktop
from pywinauto.findwindows import find_windows

from common_lib import check_program_installed, print_all_windows, run_file_exe, check_app_installed, \
    check_app_installed_32, check_app_existed, connect_app, click_without_id

result = check_app_existed('Band')
print(result)
print_all_windows()
#
# window = connect_app('Setup - Formtec Design Pro 9')
# click_without_id(window, 'I accept the agreement', 'RadioButton')
# click_without_id(window, 'Next', 'Button')
# click_without_id(window, 'Next', 'Button')
# click_without_id(window, 'Next', 'Button')
# click_without_id(window, 'Next', 'Button')
# click_without_id(window, '작업하고 계신 모든 파일을 저장 후, 설치를 진행해주세요.', 'CheckBox')
# click_without_id(window, 'Install', 'Button')
# print(window.print_control_identifiers())
# def IPinsideLWS():
#     try:
#         result = check_program_installed('IPinside LWS Agent')
#         if result:
#             return result
#         # Đường dẫn đến tệp thực thi
#         file_path = os.path.join(download_directory, 'APS_Engine.exe')
#
#         if not os.path.isfile(file_path):
#             download_by_link('https://mybank.ibk.co.kr/IBK/uib/sw/yettiesoft/APS/APS_Engine.exe')
#             sleep(10)
#
#         # Hàm kiểm tra xem nếu đã tồn tại file cài đặt thì run nó
#         run_file_exe(file_path)
#         sleep(2)
#         # Kết nối tới màn hình cài đặt app
#         # target_window = connect_app('APS Engine')
#         #
#         # #Click next
#         # click_object(target_window, '´ÙÀ½ >', '1', 'Button')
#         #
#         # # Kiem tra xem da cai dat thanh cong hay chua
#         # result = check_program_installed('APS Engine')
#         # return result
#     except Exception as e:
#         print(f'error install: {e}')
#         return False

# print_all_windows()


# from pywinauto import Application, Desktop
#
# # Kết nối với cửa sổ 'Battle.net Setup'
# app = Application(backend="uia").connect(title="Battle.net Setup")
# dlg = app.window(title="Battle.net Setup")
# print(dlg.print_control_identifiers())

# Tìm và click vào nút 'Continue'
# continue_button = dlg.child_window(title="Continue", control_type="Button")
#
# # Kiểm tra nếu nút 'Continue' tồn tại và click vào nó
# if continue_button.exists():
#     continue_button.click()
#     print("Đã click vào nút 'Continue'")
# else:
#     print("Không tìm thấy nút 'Continue'")


#
# result = check_app_installed('Zoom')
# print(result)


# Check app installed
# for i in range(36):
#     result = check_program_installed(app_name)
#     if result:
#         return result
#     sleep(10)

