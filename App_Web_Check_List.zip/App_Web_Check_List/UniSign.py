import os, subprocess
from time import sleep
from AppOpener import open

from pywinauto import Application, Desktop
from selenium.webdriver.common.by import By

from common_lib import download_directory, connect_app, check_program_installed, \
    download_and_execute, print_all_windows, click_without_id, click_object, download_by_link, click_by_xpath, \
    get_latest_file, run_file_exe, download_exe_file, install_app_silent, check_app_installed, close_app, check_app_existed

def UniSign(app_name, file_name_exe, download_link):
    # Hàm check xem app có tồn tại không cho riêng trường hợp này
    def check_app(app_name):
        app_name = "CROSSCERT UniCRSV3"
        try:
            open('Settings')
            app = Application(backend='uia').connect(title='Settings', timeout=10)
            target_window = app.window(title='Settings')
            target_window.set_focus()

            apps = target_window.child_window(title='Apps', control_type='ListItem')
            apps.wait('exists ready', timeout=10).click_input()

            installed_app = target_window.child_window(title='Installed apps', control_type='ListItem')
            installed_app.wait('exists ready', timeout=10).click_input()
            sleep(2)

            check = target_window.child_window(title_re=app_name, control_type='Text')
            if check.exists():
                target_window.close()
                return True
            else:
                target_window.close()
                return None
        except subprocess.CalledProcessError as e:
            print(f"An error occurred: {e}")
            return

    try:
        # Check app is installed
        if check_app(app_name):
            return True

        file_path = os.path.join(download_directory, file_name_exe)
        if not os.path.isfile(file_path):
            file_path = download_exe_file(file_name_exe, download_link, 60)

        # Run file exe
        if file_path:
            # Install app
            install_app_silent(file_path, "/S")
        else:
            print('Time out')
            return False

        # Check app installed
        for i in range(60):
            if check_app(app_name):
                return True
            sleep(5)

    except Exception as e:
        print(f'error app: {e}')
        return False

test = UniSign('UniSign', 'UniSignCRSV3Setup.exe', 'https://unisign.co.kr/EXE/install/UniSignCRSV3Setup.exe')
print(test)