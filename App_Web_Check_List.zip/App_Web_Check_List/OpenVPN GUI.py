import os, subprocess
from time import sleep

from pywinauto import Application, Desktop
from selenium.webdriver.common.by import By

from common_lib import download_directory, connect_app, check_program_installed, \
    download_and_execute, print_all_windows, click_without_id, click_object, download_by_link, click_by_xpath, \
    get_latest_file, run_file_exe, download_exe_file, install_app_silent, check_app_installed, close_app, check_app_existed

def OpenVPN_GUI(app_name, file_name_exe, download_link):
    try:
        # Check app is installed
        if check_app_existed(app_name):
            return True

        file_path = os.path.join(download_directory, file_name_exe)
        if not os.path.isfile(file_path):
            file_path = download_exe_file(file_name_exe, download_link, 60)

        # Run file exe
        if file_path:
            # Install app
            command = f'msiexec /i "{file_path}" /passive'
            subprocess.run(command)
        else:
            print('Time out')
            return False

        # Check app installed
        for i in range(60):
            if check_app_existed(app_name):
                return True
            sleep(5)

    except Exception as e:
        print(f'error app: {e}')
        return False

test = OpenVPN_GUI('OpenVPN GUI', 'OpenVPN-2.6.13-I002-amd64.msi', 'https://swupdate.openvpn.net/community/releases/OpenVPN-2.6.13-I002-amd64.msi')
print(test)