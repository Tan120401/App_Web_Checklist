import os
from time import sleep

from pywinauto import Application, Desktop
from selenium.webdriver.common.by import By

from common_lib import download_directory, connect_app, check_program_installed, \
    download_and_execute, print_all_windows, click_without_id, click_object, download_by_link, click_by_xpath, \
    get_latest_file, run_file_exe, download_exe_file, install_app_silent, check_app_installed, close_app, check_app_existed

def Virus_Scan_House_Call(app_name, file_name_exe, download_link):
    app_name = "Housecall"
    try:
        # Check app is installed
        if check_app_existed(app_name):
            return True

        file_path = os.path.join(download_directory, file_name_exe)
        if not os.path.isfile(file_path):
            file_path = download_exe_file(file_name_exe, download_link, 60)

        # Get latest file
        if os.path.isfile(file_path):
            return True
        else:
            print('Download app error')
            return False

    except Exception as e:
        print(f'error app: {e}')
        return False

test = Virus_Scan_House_Call('Virus Scan House Call', 'HousecallLauncher64.exe', 'https://ti-res.trendmicro.com/ti-res/hc/HousecallLauncher64.exe?utm_source=ft')
print(test)